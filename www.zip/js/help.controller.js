'use strict';

app.controller('helpCtrl', ['$scope',  function($scope){

}]);
